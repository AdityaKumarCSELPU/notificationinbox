package com.example.notificationinbox

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow


@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationModel>>

    @Query("SELECT * FROM notifications WHERE id = :notificationId LIMIT 1")
    suspend fun getById(notificationId: String): NotificationModel?


    // IGNORE means a repeated FCM ID will not create a duplicate row.
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(notification: NotificationModel)


    @Query("UPDATE notifications SET isRead = 1 WHERE id = :notificationId")
    suspend fun markRead(notificationId: String)


    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllRead()


    @Query("DELETE FROM notifications WHERE id = :notificationId")
    suspend fun deleteById(notificationId: String)
}
