package com.example.notificationinbox

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [NotificationModel::class], version = 1, exportSchema = false)
abstract class NotificationDatabase : RoomDatabase() {
    abstract fun notificationDao(): NotificationDao
    companion object {
        @Volatile private var INSTANCE: NotificationDatabase? = null
        fun getDatabase(context: Context): NotificationDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, NotificationDatabase::class.java, "notification_inbox.db")
                .build().also { INSTANCE = it }
        }
    }
}
