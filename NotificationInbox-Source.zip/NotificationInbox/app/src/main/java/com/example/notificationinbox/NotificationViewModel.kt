package com.example.notificationinbox

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
class NotificationViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = NotificationRepository(NotificationDatabase.getDatabase(application).notificationDao())
    val notifications = repository.notifications
    fun markRead(id: String) = viewModelScope.launch { repository.markRead(id) }
    fun markAllRead() = viewModelScope.launch { repository.markAllRead() }
    fun delete(id: String) = viewModelScope.launch { repository.delete(id) }
    fun getById(id: String, callback: (NotificationModel?) -> Unit) = viewModelScope.launch {
        callback(repository.getById(id))
    }
}
