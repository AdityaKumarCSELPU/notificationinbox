package com.example.notificationinbox

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import java.text.DateFormat
import java.util.Date

class NotificationAdapter(private val onClick: (NotificationModel) -> Unit) : RecyclerView.Adapter<NotificationAdapter.NotificationViewHolder>() {
    private var items: List<NotificationModel> = emptyList()
    fun submitList(list: List<NotificationModel>) { items = list; notifyDataSetChanged() }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_notification, parent, false)
        return NotificationViewHolder(view)
    }
    override fun onBindViewHolder(holder: NotificationViewHolder, position: Int) = holder.bind(items[position], onClick)
    override fun getItemCount() = items.size
    class NotificationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val banner: ImageView = itemView.findViewById(R.id.imgBanner)
        private val title: TextView = itemView.findViewById(R.id.tvTitle)
        private val description: TextView = itemView.findViewById(R.id.tvDescription)
        private val time: TextView = itemView.findViewById(R.id.tvTime)
        private val state: TextView = itemView.findViewById(R.id.tvReadState)
        fun bind(item: NotificationModel, onClick: (NotificationModel) -> Unit) {
            title.text = item.title.ifBlank { "Untitled notification" }
            description.text = item.description.ifBlank { "No description" }
            time.text = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(item.timestamp))
            state.text = if (item.isRead) "Read" else "Unread"
            state.visibility = if (item.isRead) View.GONE else View.VISIBLE
            banner.load(item.bannerImg.takeIf { it.startsWith("https://") || it.startsWith("http://") }) {
                placeholder(android.R.drawable.ic_menu_gallery)
                error(android.R.drawable.ic_menu_gallery)
            }
            itemView.setOnClickListener { onClick(item) }
        }
    }
}
