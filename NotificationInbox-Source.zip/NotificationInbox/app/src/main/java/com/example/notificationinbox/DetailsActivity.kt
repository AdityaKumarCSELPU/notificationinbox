package com.example.notificationinbox

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import coil.load
import java.text.DateFormat
import java.util.Date

class DetailsActivity : AppCompatActivity() {
    companion object { const val EXTRA_ID = "notification_id" }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        val id = intent.getStringExtra(EXTRA_ID) ?: run { finish(); return }
        val vm = ViewModelProvider(this)[NotificationViewModel::class.java]
        vm.markRead(id)
        vm.getById(id) { item ->
            if (item == null) { finish(); return@getById }
            findViewById<ImageView>(R.id.imgDetailBanner).load(item.bannerImg.takeIf { it.startsWith("https://") || it.startsWith("http://") }) {
                placeholder(android.R.drawable.ic_menu_gallery)
                error(android.R.drawable.ic_menu_gallery)
            }
            findViewById<TextView>(R.id.tvDetailTitle).text = item.title.ifBlank { "Untitled notification" }
            findViewById<TextView>(R.id.tvDetailDescription).text = item.description.ifBlank { "No description available" }
            findViewById<TextView>(R.id.tvDetailTime).text = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(item.timestamp))
        }
    }
}
