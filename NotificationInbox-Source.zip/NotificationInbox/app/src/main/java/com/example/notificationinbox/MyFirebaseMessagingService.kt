package com.example.notificationinbox


import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MyFirebaseMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        // Use a data-only FCM message so this callback can save it in the inbox.
        val data = message.data
        val title = data["title"] ?: message.notification?.title ?: "New Notification"
        val description = data["description"] ?: message.notification?.body.orEmpty()
        val id = data["id"] ?: message.messageId ?: System.currentTimeMillis().toString()
        val banner = data["bannerImg"].orEmpty()
        val timestamp = data["timestamp"]?.toLongOrNull() ?: System.currentTimeMillis()
        val item = NotificationModel(id, title, description, banner, timestamp, false)
        CoroutineScope(Dispatchers.IO).launch {
            NotificationDatabase.getDatabase(applicationContext).notificationDao().insert(item)
        }
        NotificationHelper.show(this, item)
    }
}
