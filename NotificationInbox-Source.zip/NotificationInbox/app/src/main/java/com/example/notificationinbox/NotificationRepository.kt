package com.example.notificationinbox

import kotlinx.coroutines.flow.Flow
class NotificationRepository(private val dao: NotificationDao) {
    val notifications: Flow<List<NotificationModel>> = dao.getAllNotifications()
    suspend fun save(item: NotificationModel) = dao.insert(item)
    suspend fun getById(id: String) = dao.getById(id)
    suspend fun markRead(id: String) = dao.markRead(id)
    suspend fun markAllRead() = dao.markAllRead()
    suspend fun delete(id: String) = dao.deleteById(id)
}
