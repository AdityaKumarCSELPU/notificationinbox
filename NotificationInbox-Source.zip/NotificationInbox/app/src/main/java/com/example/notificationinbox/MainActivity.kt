package com.example.notificationinbox


import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var viewModel: NotificationViewModel
    private lateinit var adapter: NotificationAdapter
    private lateinit var emptyText: TextView
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        requestNotificationPermissionIfNeeded()
        viewModel = ViewModelProvider(this)[NotificationViewModel::class.java]
        emptyText = findViewById(R.id.tvEmpty)
        val recycler = findViewById<RecyclerView>(R.id.rvNotifications)
        adapter = NotificationAdapter { item ->
            startActivity(Intent(this, DetailsActivity::class.java).putExtra(DetailsActivity.EXTRA_ID, item.id))
        }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter
        lifecycleScope.launch {
            viewModel.notifications.collect { list ->
                adapter.submitList(list)
                emptyText.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }
    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
